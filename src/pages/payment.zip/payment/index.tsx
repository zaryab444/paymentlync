import React, { useState , Fragment } from 'react';
import 'antd/dist/antd.css';

import {Row,Col,Card,Divider,Input,Button,Typography,Form,notification,Modal} from 'antd';
import { useHistory } from "react-router";



import {Elements} from '@stripe/react-stripe-js';
import {loadStripe} from '@stripe/stripe-js';

import CheckoutForm from "./stripe2/CheckoutForm";
import "./payment.css"


var stripePromise = loadStripe('pk_test_Ww9g5f0352hp6y8fNsh5m3HN');


const { confirm } = Modal;

var activeDiv = "classA"

function Payment() {
    const [paymentCompleted, setPaymentCompleted] = useState(false);

    const history = useHistory();
    const Text=Typography;
    let company="Abc Company";
    let Address="123 Street NY City US"
    const monthNames = ["January", "February", "March", "April", "May", "June",
        "July", "August", "September", "October", "November", "December"
    ];
    let Amount='768.00';

    return (

        <Fragment>
     
          <Row style={{marginTop:'5%'}}>
              <Col span={8} lg={8} md={4} xs={2} sm={2}></Col>
              <Col span={8} lg={8} md={16} xs={20} sm={20}>
              <section class="paymentPage">
                  <Card style={{height:'90vh'}} hoverable>
    
                  <div className="classA" id="classA">
                      <Row style={{borderBottom:'1px solid lightgray',paddingBottom:'2%'}}>
                          <Col style={{marginTop:'8%'}} span={24}>
                              <img alt="not Found" style={{display:'block',marginLeft:'auto',marginRight:'auto',width:'50%'}} src=""/>
                          </Col>
                          <Col style={{textAlign:'center',marginTop:'2%',fontSize:'16px'}} span={24}>
                              <b>2602, 26th Floor, Mazaya Business Avenue, BB2, <br />
                                    Jumeirah Lakes Towers, Dubai, UAE.</b>
                          </Col>
                          <Col style={{textAlign:'center',marginTop:'2%',fontSize:'24px'}} span={24}>
                              <b>$ 175.00</b>
                          </Col>
                          <Col style={{textAlign:'center',marginTop:'2%',fontSize:'16px'}} span={24}>
                              <p>Requested on {monthNames[new Date().getMonth()]} {new Date().getDate()},{new Date().getFullYear()}</p>
                          </Col>
                      </Row>
                      <PaymentLine name={"Bill to Ahmed"} value={'Ahmed'}/>
                      <PaymentLine name={"Design"} value={'$175.00'}/>
                      <PaymentLine name={"Total Due"} value={'$175.00'}/>
                      <Row style={{marginBottom:'5%'}}>
                          <Col style={{textAlign:'center',marginTop:'5%'}} span={24}>
                              <Button style={{width:'90%'}} type={'primary'}
                             onClick={firstDiv}
                              
                              >PAY WITH CARD</Button>
                          </Col>
                      </Row>
    
                      </div>
    
                      <div  className="classB" id="classB">
    
                      <Elements stripe={stripePromise}>
                      <CheckoutForm amount={175} setPaymentCompleted={setPaymentCompleted}/>
            </Elements>
    
          </div>

          <div  className="classC" id="classC">
    <img src="https://static.thenounproject.com/png/1589735-200.png" className="declineImg"></img>
    <h1 className="warning">Payment Declined</h1>
    <div onClick={showPaymentCard}>
    <img src="https://cdn.onlinewebfonts.com/svg/img_106832.png" className="retryImg"></img>
    
    <br />
    <h3>Click here to Retry</h3>
    </div>
</div>


<div  className="classD" id="classD">
    <img src="https://cdn2.iconfinder.com/data/icons/project-management-8/500/Approval-2-512.png" className="declineImg"></img>
    <h1 className="success">Payment Approved</h1>
</div>
    
        
    
                  </Card>
                  </section>
              </Col>
              <Col span={8} lg={8} md={4} xs={2} sm={2}></Col>
          </Row>
     
          </Fragment>
    
    
           
      );
    
    
    
      function firstDiv()
      {
    
    
        var classA = document.getElementById("classA");
        
        var classB = document.getElementById("classB");
        classA.classList.add("slideUp");
        classB.classList.add("slideUpfromDown");
    
    
      };  
      

      function showPaymentCard(){
        var classB = document.getElementById("classB");
        var classC = document.getElementById("classC");
     
        classB.classList.remove("slideuptwice");
        classC.classList.remove("slideupdecline");


      }
    
    
    
      }
    
    
    const PaymentLine=({name,value})=>{
      return(
          <div style={{borderBottom:'1px solid lightgray',padding:'4%'}}>
              <Row>
                  <Col span={12}>
                      {name}
                  </Col>
                  <Col style={{textAlign:'right'}} span={12}>
                      {value}
                  </Col>
              </Row>
          </div>
      );
    };
    
    
    
    
    
    
    
    
    export default Payment;
    